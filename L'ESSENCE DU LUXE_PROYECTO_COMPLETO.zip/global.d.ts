/**
 * GLOBAL.D.TS - Definiciones de tipos globales
 * Mejora el autocompletado en VS Code
 */

declare module '*.png' {
  const value: any;
  export default value;
}

declare module '*.jpg' {
  const value: any;
  export default value;
}

declare module '*.json' {
  const value: any;
  export default value;
}
